<?php

namespace App\Model\modul_keuangan;

use Illuminate\Database\Eloquent\Model;

class dk_receivable extends Model
{
    protected $table = 'dk_receivable';
    public $primaryKey = 'rc_id';
}
