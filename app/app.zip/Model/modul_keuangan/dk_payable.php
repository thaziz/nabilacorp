<?php

namespace App\Model\modul_keuangan;

use Illuminate\Database\Eloquent\Model;

class dk_payable extends Model
{
    protected $table = 'dk_payable';
    public $primaryKey = 'py_id';
}
